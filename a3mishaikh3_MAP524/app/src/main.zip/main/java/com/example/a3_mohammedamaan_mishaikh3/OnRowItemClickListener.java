package com.example.a3_mohammedamaan_mishaikh3;


import com.example.a3_mohammedamaan_mishaikh3.models.Characters;

public interface OnRowItemClickListener {
    void OnItemClickListener(Characters item);
}