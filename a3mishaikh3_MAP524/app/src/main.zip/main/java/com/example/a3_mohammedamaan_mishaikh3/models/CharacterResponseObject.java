package com.example.a3_mohammedamaan_mishaikh3.models;

import com.example.a3_mohammedamaan_mishaikh3.models.Characters;

import java.util.List;

public class CharacterResponseObject {

    private List<Characters> results;

    public List<Characters> getResults() {
        return results;
    }
}
